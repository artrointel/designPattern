int main()
{
  extern void crash(void);

  crash();
  return 0;
}
